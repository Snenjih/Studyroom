# Projekt-Fortschritt

👉 **Nächste Task:** T000 — Vollständigen Task-Breakdown generieren

> Diese Datei wird ab T000 automatisch von Claude Code gepflegt (ein Kästchen pro Task,
> ergänzt um alle in T000 generierten Tasks). Bis dahin ist nur die Bootstrap-Task gelistet.

## Phase 00 — Bootstrap
- [ ] T000 — Vollständigen Task-Breakdown generieren (`tasks/00-bootstrap/`)

## Phase 01 — Fundament
_wird von T000 befüllt (Next.js-Setup, Docker-Compose-Skeleton, Auth-Grundgerüst,
Basis-Rollenmodell, Kern-Tabellen)_

## Phase 02 — Core MVP
_wird von T000 befüllt (Dashboard, Programs/Courses CRUD, 2-3 hartcodierte Course-Types,
Enrollments & Progress, Settings-Grundgerüst)_

## Phase 03 — Modul-System & Type-Engine
_wird von T000 befüllt (generisches Course-Type-Schema, Type-Editor-UI, Modul-Registry,
dynamische Permissions)_

## Phase 04 — Code-Execution-Modul
_wird von T000 befüllt (Sandbox-Service/Piston, Course-Type "Softwareentwicklung",
Ressourcenlimits)_

## Phase 05 — Ausbau
_wird von T000 befüllt (Zertifikate, Foren, Notifications, Analytics, Audit-Log, i18n)_

## Phase 06 — MCP & Integrationen
_wird von T000 befüllt (MCP-Server der Instanz, REST/Webhook-API, optional KI-gestützte
Content-Erstellung)_

## Phase 07 — Self-Hosting-Reife
_wird von T000 befüllt (Backup/Restore, Update-Mechanismus, Doku für Self-Hoster)_
